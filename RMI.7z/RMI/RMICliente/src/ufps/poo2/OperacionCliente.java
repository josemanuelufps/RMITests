package ufps.poo2;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class OperacionCliente{

	public static void main(String[] args) {
		OperacionInterfaz servidor;
		
		String direccionServidor = "localhost";
		int puertoServidor = 3232;
		
		try {
			Registry registro = LocateRegistry.getRegistry(direccionServidor, puertoServidor);
			servidor = (OperacionInterfaz)(registro.lookup("operacionServidor"));
			int mayor = servidor.calcularMayor(5, 1);
			System.out.println("Mayor: " + mayor);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

}
