package ufps.poo2;

import java.net.InetAddress;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

public class OperadorServidor extends UnicastRemoteObject implements OperacionInterfaz{
	
	private static final long serialVersionUID = 9061868373835430621L;
	private final int PUERTO = 3232;
	
	public OperadorServidor () throws RemoteException{
		
	}
	
	public static void main(String [] args) throws Exception{
		(new OperadorServidor()).iniciarServidor();
	}

	private void iniciarServidor() {
		try {
			String dirIP = (InetAddress.getLocalHost()).toString();
			System.out.println("Escuchando en ..." + dirIP + ":" + PUERTO);
			Registry registro = LocateRegistry.createRegistry(PUERTO);
			registro.bind("operacionServidor", (OperacionInterfaz)this);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public int calcularMayor(int a, int b) {
		if (a>b) {
			return a;
		}
		else {
			return b;
		}
	}
	
}
